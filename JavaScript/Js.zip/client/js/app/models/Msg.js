class Msg{
    constructor(t=''){
        this._text=t
    }

    get text(){
        return this._text
    }
    set text(t){
        this._text=t
    }

}